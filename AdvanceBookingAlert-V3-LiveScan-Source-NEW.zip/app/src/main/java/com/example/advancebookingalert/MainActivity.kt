package com.example.advancebookingalert

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    private val requestCapture = 401
    private val prefs by lazy { getSharedPreferences("filters", Context.MODE_PRIVATE) }
    private val values = listOf(20, 30, 40, 50, 60, 70, 80, 90, 100)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannels()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        root.addView(TextView(this).apply {
            text = "Advance Booking Alert V3"
            textSize = 25f
        })
        root.addView(TextView(this).apply {
            text = "Live Scan • Seluruh Sabah"
            textSize = 15f
            setPadding(0, 8, 0, 22)
        })

        root.addView(TextView(this).apply { text = "Pilih tambang minimum" })
        val spinner = Spinner(this)
        val labels = values.map { if (it == 100) "RM100 ke atas" else "RM$it" }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val old = prefs.getInt("min_fare", 20)
        spinner.setSelection(values.indexOf(old).coerceAtLeast(0))
        root.addView(spinner)

        root.addView(TextView(this).apply {
            text = "\\nKawasan: Seluruh Sabah (tiada penapis lokasi)."
            textSize = 15f
        })

        root.addView(Button(this).apply {
            text = "Simpan filter"
            setOnClickListener {
                prefs.edit().putInt("min_fare", values[spinner.selectedItemPosition]).apply()
                Toast.makeText(this@MainActivity, "Filter disimpan.", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(Button(this).apply {
            text = "MULA LIVE SCAN"
            setOnClickListener {
                prefs.edit().putInt("min_fare", values[spinner.selectedItemPosition]).apply()
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
            }
        })

        root.addView(Button(this).apply {
            text = "HENTIKAN LIVE SCAN"
            setOnClickListener {
                stopService(Intent(this@MainActivity, LiveScanService::class.java))
                Toast.makeText(this@MainActivity, "Arahan henti dihantar.", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(TextView(this).apply {
            text = "\\nCara guna:\\n1. Pilih tambang minimum dan simpan.\\n2. Tekan MULA LIVE SCAN.\\n3. Android akan tunjuk dialog kebenaran rakaman skrin; pilih Start now.\\n4. Tukar ke Grab Driver dan buka Booking Planner > Advance Booking.\\n5. Aplikasi membaca skrin dan beri alert jika nampak tambang yang melepasi filter.\\n6. Tekan HENTIKAN LIVE SCAN selepas selesai.\\n\\nNotifikasi rakaman skrin Android akan kekal kelihatan semasa sesi aktif. Aplikasi tidak auto-accept."
            textSize = 14f
            setPadding(0, 20, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, LiveScanService::class.java).apply {
                putExtra(LiveScanService.EXTRA_RESULT_CODE, resultCode)
                putExtra(LiveScanService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service)
            else startService(service)
            Toast.makeText(this, "Live Scan dimulakan. Buka Grab Booking Planner.", Toast.LENGTH_LONG).show()
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(
                LiveScanService.SERVICE_CHANNEL, "Live Scan aktif", NotificationManager.IMPORTANCE_LOW
            ))
            nm.createNotificationChannel(NotificationChannel(
                LiveScanService.ALERT_CHANNEL, "Job Advance Booking", NotificationManager.IMPORTANCE_HIGH
            ))
        }
    }
}
