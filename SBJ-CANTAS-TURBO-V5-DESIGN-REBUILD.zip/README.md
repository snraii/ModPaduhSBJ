# SBJ CANTAS V5

Android project source for the SBJ CANTAS black/neon-green Advance Booking screen-monitoring companion.

## Current capabilities
- Dark/neon-green interface and service filters
- Minimum fare, pickup distance and avoid-area settings
- All Times / Select Time hour selection
- Configurable screen-scan interval from 1 to 5 seconds
- MediaProjection live screen monitoring and fare notifications (from existing LiveScanService)

## Important limitations
The interval controls how often the screen-monitoring workflow is configured; it does not press Grab's refresh button. The current OCR service remains a basic visible-screen fare detector and does not fully apply all UI filters. No automatic booking acceptance is implemented. Driver must review and accept bookings manually.

Build with Android Gradle Plugin 8.7.3 / Gradle 8.9 / JDK 17 using the supplied GitHub Actions workflow.
