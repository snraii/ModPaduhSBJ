package com.example.advancebookingalert

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.service.notification.NotificationListenerService
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class LiveScanService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val SERVICE_CHANNEL = "live_scan_service"
        const val ALERT_CHANNEL = "booking_alerts"
        private const val SERVICE_ID = 7201
    }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: android.hardware.display.VirtualDisplay? = null
    private var worker: HandlerThread? = null
    private var handler: Handler? = null
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val processing = AtomicBoolean(false)
    private val alerted = mutableSetOf<String>()
    private var lastAlertAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(SERVICE_ID, serviceNotification())
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                   else intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        if (resultCode != Activity.RESULT_OK || data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, Handler(mainLooper))

            worker = HandlerThread("BookingOCR").also { it.start() }
            handler = Handler(worker!!.looper)

            val metrics = resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            reader?.setOnImageAvailableListener({ imageReader ->
                val image = imageReader.acquireLatestImage() ?: return@setOnImageAvailableListener
                if (!processing.compareAndSet(false, true)) {
                    image.close()
                    return@setOnImageAvailableListener
                }
                handler?.post {
                    try { processImage(image) }
                    finally {
                        image.close()
                        processing.set(false)
                    }
                } ?: run {
                    image.close()
                    processing.set(false)
                }
            }, handler)
            display = projection?.createVirtualDisplay(
                "AdvanceBookingLiveScan", width, height, metrics.densityDpi,
                android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader?.surface, null, handler
            )
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun processImage(image: Image) {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val full = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        full.copyPixelsFromBuffer(buffer)
        val bitmap = Bitmap.createBitmap(full, 0, 0, image.width, image.height)
        full.recycle()

        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { result -> inspectText(result.text) }
            .addOnCompleteListener {
                bitmap.recycle()
            }
    }

    private fun inspectText(text: String) {
        if (text.isBlank()) return
        val lower = text.lowercase()
        val bookingScreen = lower.contains("booking planner") ||
            lower.contains("advance standard") ||
            lower.contains("advance booking")
        if (!bookingScreen) return

        val settings = getSharedPreferences("filters", Context.MODE_PRIVATE)
        val isToKlia = lower.contains("to klia") || lower.contains("ke klia") ||
            lower.contains("klia airport") && !lower.contains("from klia")
        val minimumText = if (isToKlia) settings.getString("min_fare_to_klia", "80")
                          else settings.getString("min_fare_normal", "20")
        val minFare = minimumText?.toDoubleOrNull() ?: if (isToKlia) 80.0 else 20.0
        val regex = Regex("""RM\s*([0-9]+(?:\\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE)
        val now = System.currentTimeMillis()

        regex.findAll(text).forEach { match ->
            val fare = match.groupValues[1].toDoubleOrNull() ?: return@forEach
            if (fare < minFare) return@forEach
            val key = "${match.value}|${text.hashCode()}"
            if (key in alerted) return@forEach
            if (now - lastAlertAt < 2500) return@forEach
            alerted.add(key)
            if (alerted.size > 100) alerted.clear()
            lastAlertAt = now
            sendFareAlert(match.value, text)
        }
    }

    private fun sendFareAlert(fare: String, screenText: String) {
        val excerpt = screenText.lines().filter { it.isNotBlank() }.take(7).joinToString(" • ").take(180)
        val notification = NotificationCompat.Builder(this, ALERT_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Advance Booking melepasi filter: $fare")
            .setContentText(excerpt)
            .setStyle(NotificationCompat.BigTextStyle().bigText(excerpt))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java)
            .notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)
    }

    private fun serviceNotification(): Notification =
        NotificationCompat.Builder(this, SERVICE_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Advance Booking Live Scan aktif")
            .setContentText("Sedang membaca skrin untuk tambang yang dipilih.")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    override fun onDestroy() {
        display?.release()
        reader?.close()
        projection?.stop()
        worker?.quitSafely()
        recognizer.close()
        super.onDestroy()
    }
}
