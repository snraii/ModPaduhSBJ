package com.example.advancebookingalert

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Best-effort refresh helper. It only clicks a visible, enabled node whose
 * text/content-description explicitly identifies it as Refresh/Muat semula.
 * It never taps coordinates or guesses at hidden controls.
 */
class GrabRefreshAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastClick = 0L
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences("filters", MODE_PRIVATE)
            running = prefs.getBoolean("auto_refresh_enabled", false)
            if (!running) return
            val interval = prefs.getInt("scan_seconds", 2).coerceIn(1, 5) * 1000L
            val root = rootInActiveWindow
            if (root != null && root.packageName?.toString() == "com.grabtaxi.driver2") {
                val clicked = findAndClickRefresh(root)
                if (clicked) lastClick = System.currentTimeMillis()
                root.recycle()
            }
            handler.postDelayed(this, interval)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.removeCallbacks(tick)
        handler.post(tick)
        Toast.makeText(this, "SBJ CANTAS: Accessibility aktif", Toast.LENGTH_SHORT).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // The timer performs a bounded check; events are intentionally not used to tap arbitrary UI.
    }

    override fun onInterrupt() {
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        super.onDestroy()
    }

    private fun findAndClickRefresh(node: AccessibilityNodeInfo): Boolean {
        val now = System.currentTimeMillis()
        if (now - lastClick < 900L) return false
        val labels = listOf("refresh", "refresh bookings", "muat semula", "segarkan")
        val text = node.text?.toString()?.trim()?.lowercase().orEmpty()
        val desc = node.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
        val matches = labels.any { text == it || desc == it }
        if (matches && node.isVisibleToUser && node.isEnabled && node.isClickable) {
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val clicked = findAndClickRefresh(child)
            child.recycle()
            if (clicked) return true
        }
        return false
    }
}
