package com.example.advancebookingalert

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val captureRequest = 401
    private val prefs by lazy { getSharedPreferences("filters", Context.MODE_PRIVATE) }
    private val bg = Color.rgb(4, 8, 9)
    private val panel = Color.rgb(15, 22, 22)
    private val green = Color.rgb(68, 255, 45)
    private val greenDark = Color.rgb(12, 65, 25)
    private val white = Color.WHITE
    private val muted = Color.rgb(170, 185, 178)
    private val red = Color.rgb(220, 55, 65)
    private lateinit var root: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var serviceChecks: MutableList<CheckBox>
    private lateinit var hourChecks: MutableList<CheckBox>
    private lateinit var fareKliaInput: EditText
    private lateinit var fareNormalInput: EditText
    private lateinit var kmInput: EditText
    private lateinit var avoidInput: EditText
    private lateinit var refreshBar: SeekBar
    private lateinit var refreshText: TextView
    private lateinit var allTimes: RadioButton
    private lateinit var selectTimes: RadioButton
    private lateinit var soundCheck: CheckBox
    private lateinit var continueCheck: CheckBox
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannels()
        window.statusBarColor = bg
        window.navigationBarColor = bg
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 16)
            setBackgroundColor(bg)
        }
        scroll = ScrollView(this).apply { addView(root) }
        buildHome()
        setContentView(scroll)
    }

    private fun buildHome() {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = "🏎  SBJ CANTAS"
            textSize = 27f
            setTextColor(green)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "ADVANCE BOOKING • SABAH"
            textSize = 11f
            letterSpacing = .18f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 12)
        })
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        statusText = TextView(this).apply {
            text = "●  SERVICE STOPPED"
            textSize = 12f
            setTextColor(green)
            setPadding(12, 13, 12, 13)
            background = rounded(panel, green, 14)
        }
        top.addView(statusText, LinearParams(0, -2, 1f))
        top.addView(actionButton("START LIVE SCAN", green, Color.BLACK) { requestScreenCapture() }, LinearParams(-2, -2))
        root.addView(top, LinearParams(-1, -2, bottom = 12))

        section("PERMISSION SETTING", "Kebenaran Android untuk membaca paparan yang sedang dibuka")
        root.addView(actionButton("ALLOW SCREEN CAPTURE", greenDark, green) { requestScreenCapture() }, LinearParams(-1, -2, bottom = 12))

        section("A  •  SERVICE TYPE", "Pilih servis yang mahu dipantau")
        val services = listOf("JUST GRAB", "PLUS", "6 SEATS", "PREMIUM", "EXECUTIVE", "PREMIUM | EV", "EV 6 SEATS")
        serviceChecks = mutableListOf()
        val grid = GridLayout(this).apply { columnCount = 2 }
        services.forEachIndexed { i, s ->
            val cb = check(s, "svc_$i", i == 0)
            serviceChecks.add(cb)
            grid.addView(cb, GridLayout.LayoutParams().apply {
                width = 0; height = -2
                columnSpec = GridLayout.spec(i % 2, 1f)
                setMargins(2, 2, 2, 2)
            })
        }
        root.addView(grid, LinearParams(-1, -2, bottom = 12))

        section("B  •  JOB FILTER", "Jenis tempahan dan tambang minimum")
        root.addView(spinner(listOf("Semua jenis", "Advance Booking", "Scheduled / Terjadual"), "job_type"), LinearParams(-1, -2, bottom = 7))
        label("PRICE MINIMUM • TETAPKAN SENDIRI (RM)")
        val fareCards = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val kliaCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 9, 10, 9)
            background = rounded(panel, greenDark, 11)
        }
        kliaCard.addView(TextView(this).apply {
            text = "FARE TO KLIA"
            textSize = 12f; setTextColor(green); typeface = Typeface.DEFAULT_BOLD
        })
        fareKliaInput = edit(prefs.getString("min_fare_to_klia", "80") ?: "80", "RM")
        kliaCard.addView(fareKliaInput)
        val normalCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 9, 10, 9)
            background = rounded(panel, greenDark, 11)
        }
        normalCard.addView(TextView(this).apply {
            text = "FARE NORMAL"
            textSize = 12f; setTextColor(green); typeface = Typeface.DEFAULT_BOLD
        })
        fareNormalInput = edit(prefs.getString("min_fare_normal", "20") ?: "20", "RM")
        normalCard.addView(fareNormalInput)
        fareCards.addView(kliaCard, LinearParams(0, -2, 1f).apply { marginEnd = 6 })
        fareCards.addView(normalCard, LinearParams(0, -2, 1f).apply { marginStart = 6 })
        root.addView(fareCards, LinearParams(-1, -2, bottom = 10))
        root.addView(TextView(this).apply {
            text = "Tambang minimum KLIA dan tambang biasa disimpan secara berasingan."
            textSize = 10f; setTextColor(muted)
        }, LinearParams(-1, -2, bottom = 8))
        label("Penapis destinasi")
        root.addView(spinner(listOf("Semua destinasi", "Ke KLIA", "Dari KLIA"), "destination"), LinearParams(-1, -2, bottom = 12))

        section("C  •  TIME", "Pilih masa pemantauan")
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        allTimes = RadioButton(this).apply { id = View.generateViewId(); text = "All Times"; setTextColor(white); buttonTintList = ColorStateList.valueOf(green) }
        selectTimes = RadioButton(this).apply { id = View.generateViewId(); text = "Select Time"; setTextColor(white); buttonTintList = ColorStateList.valueOf(green) }
        rg.addView(allTimes); rg.addView(selectTimes)
        rg.check(if (prefs.getBoolean("all_times", true)) allTimes.id else selectTimes.id)
        root.addView(rg)
        hourChecks = mutableListOf()
        val hourGrid = GridLayout(this).apply { columnCount = 3 }
        val hours = (0..23).map { h -> if (h == 0) "12 AM" else if (h < 12) "$h AM" else if (h == 12) "12 PM" else "${h - 12} PM" }
        hours.forEachIndexed { i, h ->
            val cb = check(h, "hour_$i", false)
            hourChecks.add(cb)
            hourGrid.addView(cb, GridLayout.LayoutParams().apply { width = 0; height = -2; columnSpec = GridLayout.spec(i % 3, 1f) })
        }
        root.addView(hourGrid, LinearParams(-1, -2, bottom = 6))
        root.addView(actionButton("SELECT ALL TIMES", greenDark, green) {
            hourChecks.forEach { it.isChecked = true }
            selectTimes.isChecked = true
        }, LinearParams(-1, -2, bottom = 12))

        section("D  •  DELAY PERIOD", "Kekerapan semakan skrin (bukan klik refresh Grab)")
        refreshText = TextView(this).apply { setTextColor(green); textSize = 15f; gravity = Gravity.CENTER }
        root.addView(refreshText)
        refreshBar = SeekBar(this).apply {
            max = 4
            progress = (prefs.getInt("scan_seconds", 2) - 1).coerceIn(0, 4)
            progressTintList = ColorStateList.valueOf(green)
            thumbTintList = ColorStateList.valueOf(green)
        }
        refreshBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { refreshText.text = "${progress + 1},000 ms  •  ${progress + 1} saat" }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        refreshText.text = "${refreshBar.progress + 1},000 ms  •  ${refreshBar.progress + 1} saat"
        root.addView(refreshBar)
        root.addView(TextView(this).apply {
            text = "Live Scan memeriksa paparan skrin pada sela masa dipilih. Ia tidak menekan butang Refresh dalam Grab."
            textSize = 11f; setTextColor(muted)
        }, LinearParams(-1, -2, bottom = 12))

        section("E  •  PICKUP KM & AVOID AREA", "Had jarak pickup dan kawasan yang mahu dielakkan")
        label("Pickup maksimum (KM) • 0 = tiada had")
        kmInput = edit(prefs.getString("pickup_km", "0") ?: "0", "Contoh: 15")
        root.addView(kmInput, LinearParams(-1, -2, bottom = 7))
        label("Avoid Area • pisahkan dengan koma")
        avoidInput = edit(prefs.getString("avoid_area", "") ?: "", "Contoh: Tuaran, Papar")
        root.addView(avoidInput, LinearParams(-1, -2, bottom = 12))

        section("F  •  SETTING AUTOBOT", "Tetapan bunyi dan kesinambungan pemantauan")
        soundCheck = check("Bunyi amaran Turbo Racing", "sound", true)
        continueCheck = check("Teruskan Live Scan selepas alert", "continue_scan", true)
        root.addView(soundCheck); root.addView(continueCheck)
        root.addView(actionButton("▶  TEST TURBO ALERT", greenDark, green) {
            android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 90).startTone(android.media.ToneGenerator.TONE_PROP_ACK, 450)
            Toast.makeText(this, "Contoh bunyi amaran dimainkan", Toast.LENGTH_SHORT).show()
        }, LinearParams(-1, -2, bottom = 8))
        root.addView(actionButton("SAVE ALL SETTINGS", green, Color.BLACK) { saveSettings(); Toast.makeText(this, "Tetapan disimpan", Toast.LENGTH_SHORT).show() }, LinearParams(-1, -2, bottom = 8))
        root.addView(actionButton("STOP LIVE SCAN", red, white) {
            stopService(Intent(this, LiveScanService::class.java))
            statusText.text = "●  SERVICE STOPPED"
            Toast.makeText(this, "Live Scan dihentikan", Toast.LENGTH_SHORT).show()
        }, LinearParams(-1, -2, bottom = 12))
        root.addView(TextView(this).apply {
            text = "NOTA: SBJ CANTAS membaca teks yang kelihatan pada skrin Grab Booking Planner dan memberi amaran berdasarkan tambang minimum. Semakan skrin tidak sama dengan menekan refresh Grab. Penerimaan tempahan dibuat secara manual."
            textSize = 11f; setTextColor(muted); setPadding(4, 10, 4, 10)
        })
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, 12, 0, 0) }
        listOf("HOME", "FILTER", "LOG", "SETTING").forEach { item ->
            nav.addView(TextView(this).apply { text = item; textSize = 10f; setTextColor(if (item == "HOME") green else muted); gravity = Gravity.CENTER; setPadding(12, 8, 12, 8) }, LinearParams(0, -2, 1f))
        }
        root.addView(nav)
    }

    private fun requestScreenCapture() {
        saveSettings()
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    private fun saveSettings() {
        val e = prefs.edit()
        serviceChecks.forEachIndexed { i, cb -> e.putBoolean("svc_$i", cb.isChecked) }
        hourChecks.forEachIndexed { i, cb -> e.putBoolean("hour_$i", cb.isChecked) }
        e.putString("min_fare_to_klia", fareKliaInput.text.toString())
            .putString("min_fare_normal", fareNormalInput.text.toString())
            .putString("pickup_km", kmInput.text.toString())
            .putString("avoid_area", avoidInput.text.toString())
            .putInt("scan_seconds", refreshBar.progress + 1)
            .putBoolean("all_times", allTimes.isChecked)
            .putBoolean("sound", soundCheck.isChecked)
            .putBoolean("continue_scan", continueCheck.isChecked)
            .apply()
    }

    private fun section(title: String, subtitle: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(13, 11, 13, 10)
            background = rounded(panel, green, 13)
        }
        box.addView(TextView(this).apply { text = title; textSize = 14f; setTextColor(green); typeface = Typeface.DEFAULT_BOLD })
        box.addView(TextView(this).apply { text = subtitle; textSize = 10f; setTextColor(muted); setPadding(0, 3, 0, 0) })
        root.addView(box, LinearParams(-1, -2, top = 10, bottom = 6))
    }

    private fun label(s: String) { root.addView(TextView(this).apply { text = s; textSize = 12f; setTextColor(white); setPadding(3, 8, 3, 4) }) }
    private fun edit(value: String, hintText: String) = EditText(this).apply {
        setText(value); hint = hintText; setTextColor(white); setHintTextColor(muted); textSize = 14f
        setSingleLine(true); setPadding(12, 10, 12, 10); background = rounded(panel, greenDark, 10)
    }
    private fun check(textValue: String, key: String, default: Boolean) = CheckBox(this).apply {
        text = textValue; textSize = 12f; setTextColor(white)
        buttonTintList = ColorStateList.valueOf(green)
        isChecked = prefs.getBoolean(key, default)
    }
    private fun spinner(items: List<String>, key: String) = Spinner(this).apply {
        val adapter = object : ArrayAdapter<String>(this@MainActivity, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                return (super.getView(position, convertView, parent) as TextView).apply { setTextColor(white); textSize = 13f; setPadding(12, 10, 12, 10); setBackgroundColor(panel) }
            }
            override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                return (super.getDropDownView(position, convertView, parent) as TextView).apply { setTextColor(white); setBackgroundColor(panel); setPadding(14, 12, 14, 12) }
            }
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        this.adapter = adapter
        if (Build.VERSION.SDK_INT >= 16) popupBackground = rounded(panel, greenDark, 8)
        setSelection(prefs.getInt(key, 0).coerceIn(items.indices))
        background = rounded(panel, greenDark, 10)
    }
    private fun actionButton(textValue: String, color: Int, textColor: Int, action: () -> Unit) = Button(this).apply {
        text = textValue; setTextColor(textColor); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        background = rounded(color, color, 12); setOnClickListener { action() }
    }
    private fun rounded(color: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat() * resources.displayMetrics.density
        setStroke((1 * resources.displayMetrics.density).toInt().coerceAtLeast(1), stroke)
    }
    private fun LinearParams(w: Int, h: Int, weight: Float = 0f, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = top; bottomMargin = bottom }

    @Deprecated("Legacy callback used for MediaProjection result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val intent = Intent(this, LiveScanService::class.java).apply {
                putExtra(LiveScanService.EXTRA_RESULT_CODE, resultCode)
                putExtra(LiveScanService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
            statusText.text = "●  LIVE SCAN ACTIVE"
            Toast.makeText(this, "Live Scan bermula. Buka Grab Booking Planner.", Toast.LENGTH_LONG).show()
        }
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(LiveScanService.SERVICE_CHANNEL, "Live Scan", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(LiveScanService.ALERT_CHANNEL, "Booking Alert", NotificationManager.IMPORTANCE_HIGH))
        }
    }
}
