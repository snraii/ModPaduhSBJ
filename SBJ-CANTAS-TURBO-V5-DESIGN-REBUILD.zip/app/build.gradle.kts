plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.advancebookingalert"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.advancebookingalert"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "5.0"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
