package com.example.advancebookingalert

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    private val requestCapture = 401
    private val prefs by lazy { getSharedPreferences("filters", Context.MODE_PRIVATE) }
    private val fares = listOf(20,30,40,50,60,70,80,90,100)
    private val bg=Color.rgb(10,16,29); private val panel=Color.rgb(20,31,49)
    private val green=Color.rgb(80,255,125); private val blue=Color.rgb(45,170,255)
    private val white=Color.WHITE; private val muted=Color.rgb(172,190,208)
    private lateinit var mode:Spinner; private lateinit var service:Spinner; private lateinit var job:Spinner
    private lateinit var minFare:Spinner; private lateinit var distance:EditText; private lateinit var blocked:EditText
    private lateinit var time:Spinner; private lateinit var interval:Spinner
    private lateinit var sound:CheckBox; private lateinit var continueScan:CheckBox

    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); channels()
        window.statusBarColor=bg; window.navigationBarColor=bg
        val page=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,24,22,30); setBackgroundColor(bg) }
        page.addView(TextView(this).apply { text="SBJCANTAS"; textSize=29f; setTextColor(green); setTypeface(null,android.graphics.Typeface.BOLD) })
        page.addView(TextView(this).apply { text="T U R B O  •  ADVANCE BOOKING SABAH"; textSize=12f; setTextColor(muted); setPadding(0,3,0,18) })
        section(page,"INTERFACE MODE","Pilih versi paparan Grab Driver")
        mode=spin(listOf("Grab Driver – Interface baharu","Grab Driver – Interface lama"),"interface_mode"); page.addView(mode)
        section(page,"SERVICE TYPE","Jenis perkhidmatan yang mahu dipantau")
        service=spin(listOf("Semua service","Just Grab","GrabCar Plus","6 Seats","Premium","Executive","GrabCar"),"service_type"); page.addView(service)
        section(page,"JOB TYPE","Jenis tempahan")
        job=spin(listOf("Semua jenis","Advance Booking","Scheduled / Terjadual"),"job_type"); page.addView(job)
        section(page,"FILTER ADVANCE","Tetapan asas penapisan tambang")
        label(page,"Tambang minimum"); minFare=Spinner(this); minFare.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,fares.map{if(it==100)"RM100 ke atas" else "RM$it"}); minFare.setSelection(fares.indexOf(prefs.getInt("min_fare",20)).coerceAtLeast(0)); page.addView(minFare)
        label(page,"Jarak maksimum (KM) – 0 = tidak ditapis"); distance=edit(prefs.getString("max_distance","0")?:"0","Contoh: 30"); page.addView(distance)
        label(page,"Blocked Area – pisahkan dengan koma (pilihan)"); blocked=edit(prefs.getString("blocked_areas","")?:"","Contoh: Inanam, Tuaran"); page.addView(blocked)
        section(page,"TIME FILTER","Pilih masa pemantauan")
        time=spin(listOf("Sepanjang masa","Pagi (06:00–11:59)","Tengah hari (12:00–17:59)","Malam (18:00–23:59)","Tetapan manual (belum disediakan)"),"time_mode"); page.addView(time)
        section(page,"TIMING CONTROL","Kawalan sela semakan skrin")
        interval=spin(listOf("1 saat","2 saat","3 saat","5 saat","10 saat"),"scan_interval"); page.addView(interval)
        section(page,"EXTRA","Pilihan notifikasi")
        sound=check("Bunyi notifikasi apabila tambang dikesan","sound_alert",true); page.addView(sound)
        continueScan=check("Teruskan Live Scan selepas alert","keep_scanning",true); page.addView(continueScan)
        page.addView(button("SIMPAN SEMUA TETAPAN",green,Color.BLACK){save(); Toast.makeText(this,"Tetapan disimpan.",Toast.LENGTH_SHORT).show()})
        page.addView(button("MULA LIVE SCAN",blue,white){save(); val m=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; startActivityForResult(m.createScreenCaptureIntent(),requestCapture)})
        page.addView(button("HENTIKAN LIVE SCAN",Color.rgb(190,55,65),white){stopService(Intent(this,LiveScanService::class.java));Toast.makeText(this,"Arahan henti dihantar.",Toast.LENGTH_SHORT).show()})
        page.addView(TextView(this).apply { text="CARA GUNA\n1. Simpan tetapan.\n2. Tekan MULA LIVE SCAN dan benarkan rakaman skrin Android.\n3. Buka Grab Driver > Booking Planner > Advance Booking.\n4. SBJCANTAS membaca teks yang kelihatan dan memberi notifikasi apabila tambang memenuhi penapis minimum.\n\nNOTA V4\nPilihan interface, service, job type, jarak, kawasan, masa dan timing disimpan sebagai tetapan. Buat masa ini, OCR masih menggunakan logik V3 dan hanya penapis tambang minimum yang aktif. Penapis lanjutan dan sela semakan belum disambungkan. Tiada auto-accept, auto-tap atau pintasan keselamatan Grab."; textSize=12f; setTextColor(muted); setPadding(4,22,4,10) })
        setContentView(ScrollView(this).apply{addView(page)})
    }
    private fun section(p:LinearLayout,t:String,s:String){val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,13,14,9);setBackgroundColor(panel)};b.addView(TextView(this).apply{text=t;textSize=14f;setTextColor(green);setTypeface(null,1)});b.addView(TextView(this).apply{text=s;textSize=11f;setTextColor(muted);setPadding(0,3,0,0)});p.addView(b,LinearLayout.LayoutParams(-1,-2).apply{topMargin=14})}
    private fun label(p:LinearLayout,t:String){p.addView(TextView(this).apply{text=t;textSize=12f;setTextColor(white);setPadding(3,12,3,5)})}
    private fun spin(items:List<String>,key:String)=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items);setSelection(prefs.getInt(key,0).coerceIn(items.indices))}
    private fun edit(v:String,h:String)=EditText(this).apply{setText(v);hint=h;setHintTextColor(muted);setTextColor(white);textSize=14f;setSingleLine(true);setPadding(12,8,12,8);setBackgroundColor(panel)}
    private fun check(t:String,k:String,d:Boolean)=CheckBox(this).apply{text=t;setTextColor(white);buttonTintList=android.content.res.ColorStateList.valueOf(green);isChecked=prefs.getBoolean(k,d)}
    private fun button(t:String,c:Int,tc:Int,fn:()->Unit)=Button(this).apply{text=t;setTextColor(tc);setBackgroundColor(c);setOnClickListener{fn()};layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=12}}
    private fun save(){prefs.edit().putInt("min_fare",fares[minFare.selectedItemPosition]).putInt("interface_mode",mode.selectedItemPosition).putInt("service_type",service.selectedItemPosition).putInt("job_type",job.selectedItemPosition).putString("max_distance",distance.text.toString()).putString("blocked_areas",blocked.text.toString()).putInt("time_mode",time.selectedItemPosition).putInt("scan_interval",interval.selectedItemPosition).putBoolean("sound_alert",sound.isChecked).putBoolean("keep_scanning",continueScan.isChecked).apply()}
    @Deprecated("Legacy callback retained for compatibility") override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==requestCapture&&resultCode==RESULT_OK&&data!=null){val i=Intent(this,LiveScanService::class.java).apply{putExtra(LiveScanService.EXTRA_RESULT_CODE,resultCode);putExtra(LiveScanService.EXTRA_RESULT_DATA,data)};if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)startForegroundService(i) else startService(i);Toast.makeText(this,"Live Scan dimulakan. Buka Grab Booking Planner.",Toast.LENGTH_LONG).show()}}
    private fun channels(){if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){val n=getSystemService(NotificationManager::class.java);n.createNotificationChannel(NotificationChannel(LiveScanService.SERVICE_CHANNEL,"Live Scan aktif",NotificationManager.IMPORTANCE_LOW));n.createNotificationChannel(NotificationChannel(LiveScanService.ALERT_CHANNEL,"Job Advance Booking",NotificationManager.IMPORTANCE_HIGH))}}
}
