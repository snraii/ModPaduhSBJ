# SBJCANTAS TURBO V4

V4 settings interface built on the existing V3 Android OCR project. Includes original user-provided launcher logo, dark neon interface, selectable interface/service/job settings, minimum fare, distance and blocked-area fields, time mode, scan interval, sound and continue-scan preferences.

IMPORTANT: The current LiveScanService remains the V3 implementation. Only the minimum-fare filter is connected to OCR matching. Other new settings are saved in preferences but are not yet enforced by OCR. Scan interval is a stored preference, not an active timer control. No auto-accept, auto-tap, or Grab security bypass is included. Screen-capture permission is required for each session.
